from django.db import models

class Contact(models.Model):
    name = models.CharField(max_length=255)
    address = models.TextField()
    profession = models.CharField(max_length=255)
    telnumber = models.CharField(max_length=20)
    email = models.EmailField()
    image = models.ImageField(upload_to='contact_images/', blank=True, null=True)

    def __str__(self):
        return self.name
